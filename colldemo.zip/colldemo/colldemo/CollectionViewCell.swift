//
//  CollectionViewCell.swift
//  colldemo
//
//  Created by Yogesh Patel on 09/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var img: UIImageView!
    
    @IBOutlet var lbl: UILabel!
}
