//
//  ViewController.swift
//  colldemo
//
//  Created by Yogesh Patel on 09/12/17.
//  Copyright © 2017 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
   
    
    
    var arrimg = [#imageLiteral(resourceName: "watch10"),#imageLiteral(resourceName: "watch3"),#imageLiteral(resourceName: "watch5"),#imageLiteral(resourceName: "watch7"),#imageLiteral(resourceName: "watch6"),#imageLiteral(resourceName: "watch8"),#imageLiteral(resourceName: "watch9"),#imageLiteral(resourceName: "watch4"),#imageLiteral(resourceName: "watch10"),#imageLiteral(resourceName: "watch3"),#imageLiteral(resourceName: "watch5"),#imageLiteral(resourceName: "watch7"),#imageLiteral(resourceName: "watch6"),#imageLiteral(resourceName: "watch8"),#imageLiteral(resourceName: "watch9"),#imageLiteral(resourceName: "watch4"),#imageLiteral(resourceName: "watch6"),#imageLiteral(resourceName: "watch8"),#imageLiteral(resourceName: "watch9"),#imageLiteral(resourceName: "watch4")]
    var arrlbl = ["Watch1","Watch2","Watch3","Watch4","Watch5","Watch6","Watch7","Watch8","Watch9","Watch10","Watch11","Watch12","Watch13","Watch14","Watch15","Watch16","Watch17","Watch18","Watch19","Watch20"]
    

    @IBOutlet var collectionview: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrlbl.count
    }
  
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        //UIcollectionviewcell * cell = collectionview.de "cell"
        
        let cell:CollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        cell.img.image = arrimg[indexPath.row]
        cell.lbl.text = arrlbl[indexPath.row]
        return cell
        
        
        
    }
    
    

}

